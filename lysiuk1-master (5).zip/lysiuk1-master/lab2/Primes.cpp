#include <bits/stdc++.h> 
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std; 
  
const int MAX = 10000; 
  

int prefix[MAX + 1]; 
  
void buildPrefix() 
{ 
    
    bool prime[MAX + 1]; 
    memset(prime, true, sizeof(prime)); 
  
    for (int p = 2; p * p <= MAX; p++) { 
  
      
        if (prime[p] == true) { 
  
         
            for (int i = p * 2; i <= MAX; i += p) 
                prime[i] = false; 
        } 
    } 
  
    
    prefix[0] = prefix[1] = 0; 
    for (int p = 2; p <= MAX; p++) { 
        prefix[p] = prefix[p - 1]; 
        if (prime[p]) 
            prefix[p]++; 
    } 
} 
  
int sieve(int L, int U) 
{ 
    return prefix[U] - prefix[L - 1]; 
} 
  
int main(int argc, char** argv) 
{ 
  int my_rank;
  int primes_part;
  int primes;
  int n_factor=10;
  int L=2, U=10000;
  buildPrefix();
  cout<<sieve(L,U)<<endl;
   MPI_Init(NULL, NULL);

    int procnumb;
    MPI_Comm_size(MPI_COMM_WORLD, &procnumb);

    int procrank;
    MPI_Comm_rank(MPI_COMM_WORLD, &procrank);
    int n =10;
    while (n<=U) {
      MPI_Bcast (&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
      primes_part= sieve (L,U);
      MPI_Reduce (&primes_part, &primes, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
      if (my_rank == 0){
	cout<<sieve(L,U)<<endl; 
      }
      n=n*n_factor;
  
    return 0; 
    MPI_Finalize();
} 
