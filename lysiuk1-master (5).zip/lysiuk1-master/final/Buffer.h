/** array of C-style strings of known maximum length, with contiguous 
    allocation. */
#include <cstring>
#include <cassert>

class Buffer {
 protected:
  char *buff;  /**< contiguously allocated space for all strings */
  int size;  /**< number of C-style strings in this array */
  int maxstr;  /**< maximum length of a string in this array */
 public:
  Buffer(int sz, int max, char *values = 0) { setup(sz, max, values); }
  Buffer() { setup(0, 0, 0); }
  Buffer(const Buffer &b) { setup(b.size, b.maxstr, b.buff); }
  ~Buffer() { if (buff != 0) delete [] buff;  buff = 0; }
  Buffer &operator=(const Buffer &b) {
    delete [] buff;  setup(b.size, b.maxstr, b.buff); return *this;  }
  /** @param indx Index of a C-style string in this array 
      @return Address of that string within the contiguous allocation for this
      Buffer */
  char *operator[](int indx) {
    assert(0 <= indx && indx < size);
    return buff + indx * (maxstr+1);
  }

  /** @param sz value for size state variable of Buffer 
      @param max value for maxstr state variable of Buffer 
      @param values If provided, bytes for initializing this array's 
      contiguous allocation;  must have length at least sz*max byte values 
      @sc deallocates any prior allocation of buff, and allocates a new 
      contiguous array of bytes for sz C-style strings of length up to max.  
      If values is provided, initializes that new array according to values */
  void reset(int sz, int max, char *values = 0) { 
    delete [] buff; setup(sz, max, values);  
  }
  /** @return Pointer to the underlying contiguously allocated pool of all 
      bytes in this Buffer */
  char *getBytes(void) { return buff; }
  int getSize(void) { return size; }
  int getMaxstr(void) { return maxstr; }
 protected:
  /** helper method for reset() */
  int setup(int sz, int max, char *values = 0) { 
    size = sz;  maxstr = max; buff = new char[size*(maxstr+1)]; 
    if (values) memcpy(buff, values, size*(maxstr+1)); 
  }
};
