#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <omp.h>
using namespace std;
#include "mpi.h"
#include "Buffer.h" 

/* Demo program for OpenMP and MPI: computes "scores" for random strings */

#define STRINGCT 1028    /* a power of 2 */
#define MAXSTRING 5      /* maximum length of a random string */
const char *text = "the cat in the hat wore the hat to the cat hat party";  
   /* comparison string for score function */

/* score function
   2 args - C-style strings
   return - maximal number of matching characters between arg1 and arg2, 
     allowing any number of insertions and deletions */

int score(const char *str1, const char *str2) {
  if (*str1 == '\0' || *str2 == '\0')
    return 0;
  // both argument strings non-empty
  if (*str1 == *str2)
    return 1 + score(str1 + 1, str2 + 1);
  else // first characters do not match
    return max(score(str1, str2 + 1), score(str1 + 1, str2));
}

/* helper function -- true if x is a power of 2, false otherwise */

int isPowerOf2(int x) {
  return (x != 0) && ((x & (x - 1)) == 0);
}

int main(int argc, char** argv) {

  /* SETUP */

  int rank;  /* MPI id for this process */
  int nprocs;    /* Number of MPI processes in this job */
  MPI_Status   status;  /* to receive status value from certain MPI calls */

  int threadct = 1;  // number of threads per process
  int head = 0;  // rank of head node, named for readability

  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

  /* parse command-line arg for number of threads per process */
  if (argc > 1)
    threadct = atoi(argv[1]);

  if (!isPowerOf2(STRINGCT) || !isPowerOf2(nprocs) || !isPowerOf2(threadct)) {
    cerr << "numbers of strings to score, processes, and threads" << endl 
	 << "must all be powers of 2, aborting" << endl;
    MPI_Finalize();
    return 0;
  }
  if (nprocs * threadct > STRINGCT) {
    cerr << "more total threads requested than strings to score, aborting" 
	 << endl;
    MPI_Finalize();
    return 0;
  }
  // assert:  data can be divided evenly among the threads and processes.  

#ifdef _OPENMP
  cout << "OpenMP defined, threadct = " << threadct << endl;
#else
  cout << "OpenMP not defined, aborting" << endl;
  MPI_Finalize();
  return 0;
#endif

  /*  BEGIN COMPUTATION */

  Buffer all;  //array of all strings to score, alloc in head node only
  Buffer some;  //array of strings for this process to score

  if (rank == head) { 
    all.reset(STRINGCT, MAXSTRING);  
    for (int i = 0;  i < STRINGCT;  i++) {
      int len = 1 + rand()%MAXSTRING;
      int j;  // index into the string all[i] currently being assigned
      for (j = 0;  j < len;  j++)
	all[i][j] = 'a' + rand() % 26;  
      all[i][len] = '\0';  
    }
    // assert: all[] holds STRINGCT random C-style strings
    // each having random length up to MAXSTRING
  }

  int spp = STRINGCT / nprocs;  // strings to score per process (a power of 2)

  if (rank == head) { 
    for (int p = 1;  p < nprocs;  p++) {
      MPI_Send(all[p*spp], spp*(MAXSTRING+1), MPI_CHAR, 
	       p, 0, MPI_COMM_WORLD); //send subarray of all[] to process p
    }
    some.reset(spp, MAXSTRING, all.getBytes());  
        // head node will score the first spp strings in all
  } else { // worker node
    some.reset(spp, MAXSTRING);
    MPI_Recv(some.getBytes(), spp*(MAXSTRING+1), MPI_CHAR, 
	     head, 0, MPI_COMM_WORLD, &status);
  }
  // assert: some holds (sub)array of sbb strings for this process to score
       
  int maxscore = -1;  // highest score seen so far
#pragma omp parallel for num_threads(threadct) reduction(max: maxscore)
  for(int i = 1; i < spp; i++) {
    int threadid = omp_get_thread_num();
    int s = score(text, some[i]);
    if (s > maxscore) {
      maxscore = s;
    } 
  }
  // assert:  maxscore is highest score seen among strings in some[]


  char hostname[MPI_MAX_PROCESSOR_NAME];
  int length;  
  MPI_Get_processor_name (hostname, &length);

  cout << "rank " << rank << "(on " << hostname << "): max score " 
       << maxscore << endl;
  
  if (rank == head) { 
    int score;
    for (int p = 1;  p < nprocs;  p++) {
      MPI_Recv(&score, 1, MPI_INT, p, 0, MPI_COMM_WORLD, &status);
      if (score > maxscore) 
	maxscore = score;
    }
    cout << "head node:  overall maximum score is " << maxscore << endl;
  } else { // worker node
    MPI_Send(&maxscore, 1, MPI_INT, head, 0, MPI_COMM_WORLD);  
  }

  MPI_Finalize();
  return 0;
}
    
