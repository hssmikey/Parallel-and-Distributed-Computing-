#include <iostream>
#include <cmath>
#include <set>

using namespace std;

void sieve(int n){
    set<int> primes;
    primes.insert(2);
    for(int i=3; i<=n ; i+=2){
        primes.insert(i);
    }       

    int p=*primes.begin();
    cout<<p<<"\n";
    primes.erase(p);

    int maxRoot = sqrt(*(primes.rbegin()));

    while(primes.size()>0){
        if(p>maxRoot){
            while(primes.size()>0){
                p=*primes.begin();
                cout<<p<<"\n";
                primes.erase(p);        
            }
            break;
        }

        int i=p*p;  
        int temp = (*(primes.rbegin()));
        while(i<=temp){
            primes.erase(i);
            i+=p;
            i+=p;
        }
        p=*primes.begin();
        cout<<p<<"\n";
        primes.erase(p);
    }
}

int main(){
    int n;
    n = 1000000;
    sieve(n);                
    return 0;
}
