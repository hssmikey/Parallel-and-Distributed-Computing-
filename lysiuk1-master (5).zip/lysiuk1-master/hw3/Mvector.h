template<typename T, std::size_t N>
class Vector{
public:
    Mvector(std::array<T,N> elems): elems_(elems)
    {}

    T length() const {
        T out = 0;
        for(auto i : elems_) out += i * i;
        return std::sqrt(out);
    }

    T dot(Vector<T,N> b) const {
        T out = 0;
        for(auto i  = 0; i < elems_.size(); ++i) out += elems_[i] * b[i];
        return out;
    }

    std::array<T,N> norm() const {
        T len = this->length();
        std::array<T,N> out = elems_;
        std::transform( out.begin(), out.end(),out.begin(),
                       std::bind2nd(std::divides<T>(), len) );
        return out;
    }

    T& operator[](std::size_t i){return elems_[i];}

private:
    std::array<T,N> elems_;
};

int main(){
    std::array<double, 3> in1 = {6.78269, 6.72, 6.76312};
    std::array<double, 3> in2 = {4.78269, 5.72, 8.76312};

    Vector<double,3> first(in1);
    Vector<double,3> second(in2);

    std::cout << "Norm of first vec = "; 
    auto norm = first.norm();
    for(auto i : norm) std::cout << i << " ";
    std::cout << std::endl;

    std::cout << "Lenght of first vec = " << first.length() << std::endl;
    std::cout << "Dot product = " << first.dot(second) << std::endl;

    return 0;
}
